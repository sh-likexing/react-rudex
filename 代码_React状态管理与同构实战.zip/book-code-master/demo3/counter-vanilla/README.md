# Redux basic example
原生JS+redux实现计数器
