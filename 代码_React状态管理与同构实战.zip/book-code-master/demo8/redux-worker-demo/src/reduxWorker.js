import createWorker from './createWorker'
import applyWorker from './applyWorker'

export { applyWorker, createWorker }
export default { applyWorker, createWorker }
