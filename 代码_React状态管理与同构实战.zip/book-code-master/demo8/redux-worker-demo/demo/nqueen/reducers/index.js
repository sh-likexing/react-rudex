import { combineReducers } from 'redux'
import nqueen from './nqueen/nqueen'

const nqueenApp = combineReducers({
	nqueen
});

export default nqueenApp