# Redux React Code Splitting Project

Redux React Code Splitting project demo

# Build & Run Instructions

- `git clone`
- `yarn install`
- `yarn start`

# Info

该项目 fork 自 [redux-react-starter](https://github.com/didierfranc/react-code-splitting)，部分内容有所改动。