const API = 'https://react.didierfranc.com'

export const SIGNUP = `${API}/signup`
export const LOGIN = `${API}/login`
export const LOGIN_WITH_TOKEN = `${API}/token`
