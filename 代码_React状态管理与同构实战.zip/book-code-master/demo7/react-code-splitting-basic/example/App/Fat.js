import React from 'react'

export default () => <h1>{"I'm fat"}</h1>