# Changelog

* Added support for classes in `createElement`