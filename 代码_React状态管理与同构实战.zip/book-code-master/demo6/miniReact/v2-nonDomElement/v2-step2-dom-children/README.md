# Changelog

* Not all children were born equal ;). Used the proper method to append each child.