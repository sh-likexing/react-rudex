# 说明

此项目来源于 Ofir Dagan 的演讲 [Build Your Own React](https://www.youtube.com/watch?v=RmAIwZeY0tk)，建议参考实现源码学习。这里 fork 一份，会添加更多 features。