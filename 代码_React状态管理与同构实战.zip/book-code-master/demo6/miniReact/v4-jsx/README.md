# Changelog

* Handle className attribute
* Support stateless component as the root react element