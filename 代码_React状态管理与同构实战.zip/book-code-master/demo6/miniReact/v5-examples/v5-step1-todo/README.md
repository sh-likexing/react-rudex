#Changelog

* Add support for `ref`
* Add support for child as an array
* Add support for child as REACT_CLASS