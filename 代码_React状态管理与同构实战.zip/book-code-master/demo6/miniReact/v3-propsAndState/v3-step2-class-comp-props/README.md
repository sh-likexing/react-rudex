# Changelog

* Introduce `React.Component` class
* Pass props to class constructor