#Changelog

* Introduce `rootDOMElement` and `rootReactElement` so
we can re-render the app.
* Add `reRender` function
* We no longer auto render classes
* Add `setState` to `React.Component`