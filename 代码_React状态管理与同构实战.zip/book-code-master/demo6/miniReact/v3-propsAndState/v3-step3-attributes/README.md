# Changelog

* Iterate on the element's properties and set them
accordingly. Events as eventListeners and Attributes
Attributes.