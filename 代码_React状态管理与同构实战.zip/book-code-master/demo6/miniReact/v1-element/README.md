# Changelog

* Support other html tags than `div`